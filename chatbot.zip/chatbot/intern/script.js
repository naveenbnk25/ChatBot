// Example of simple form interaction
document.getElementById("registrationForm").addEventListener("submit", function(e) {
    e.preventDefault();
    // Proceed to next step
    document.getElementById("verificationSection").style.display = "block";
  });
  
  document.getElementById("googleLogin").addEventListener("click", function() {
    // Simulate Google login
    alert("Google login feature would be here.");
  });
  
  document.getElementById("organizationForm").addEventListener("submit", function(e) {
    e.preventDefault();
    // Simulate fetching the meta-description
    document.getElementById("metaDescription").style.display = "block";
    document.getElementById("metaText").innerText = "This is a meta description fetched from the website!";
  });
  
  document.getElementById("testChatbotButton").addEventListener("click", function() {
    // Open the website with the dummy chatbot
    alert("Testing chatbot integration...");
  });
  
  document.getElementById("integrateButton").addEventListener("click", function() {
    // Show integration options
    document.getElementById("integrationOptions").style.display = "block";
  });
  
  document.getElementById("easyInstructionsButton").addEventListener("click", function() {
    alert("Easy integration instructions...");
  });
  
  document.getElementById("exploreAdminPanel").addEventListener("click", function() {
    alert("Exploring admin panel...");
  });
  // script.js

document.getElementById("registrationForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const email = document.getElementById("email").value;
    // Call the API to send the verification code
    fetch('/send-verification', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email: email }),
    })
      .then(response => response.json())
      .then(data => {
        if (data.message === 'Verification code sent') {
          alert('Verification code sent to your email!');
          document.getElementById("verificationSection").style.display = "block";
        }
      })
      .catch(error => {
        alert('Error sending verification code');
      });
  });
  
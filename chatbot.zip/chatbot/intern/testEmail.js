const nodemailer = require('nodemailer');

// Create the transporter object for Gmail
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'nk9741444366@gmail.com',  // Your Gmail email
    pass: 'eyqp spct pelx qqco',     // Your Gmail app password if 2FA is enabled
  },
});

// Set up email data
const mailOptions = {
  from: 'nk9741444366@gmail.com',
  to: 'naveenbnk25@gmail.com',  // Replace with the email where you want to send
  subject: 'Test Email from Nodemailer',
  text: 'This is a test email.',
};

// Send test email
transporter.sendMail(mailOptions, (error, info) => {
  if (error) {
    console.log('Error:', error);
  } else {
    console.log('Email sent: ' + info.response);
  }
});

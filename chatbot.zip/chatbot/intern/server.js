const express = require('express');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const bodyParser = require('body-parser');

const app = express();

// Middleware to parse JSON
app.use(bodyParser.json());

// Set up Gmail SMTP transport (for Gmail users)
const transporter = nodemailer.createTransport({
  service: 'gmail',  // Using Gmail's SMTP service
  auth: {
    user: 'nk9741444366@gmail.com',   // Replace with your Gmail address
    pass: 'eyqp spct pelx qqco',      // Use app password if you have 2FA enabled
  },
});

// API route to send verification code
app.post('/send-verification', (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).send('Email is required');
  }

  // Generate random 6-character verification code
  const verificationCode = crypto.randomBytes(3).toString('hex');  // Creates a 6-character string

  // Email content options
  const mailOptions = {
    from: 'nk9741444366@gmail.com',  // Your Gmail address
    to: email,                    // Recipient's email
    subject: 'Email Verification Code',
    text: `Your verification code is: ${verificationCode}`,  // Email body content
  };

  // Send the email
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log('Error:', error);  // Log the error for debugging
      return res.status(500).send('Error sending email');
    }
    // Return success message (you can store verification code here)
    return res.status(200).send({ message: 'Verification code sent', verificationCode });
  });
});

// Start the server
const port = 3000;
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
